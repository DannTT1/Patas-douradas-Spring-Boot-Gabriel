package com.senacwebpatasdouradas.demo.entity;

public enum TipoConta {
    CLIENTE,
    VENDEDOR
}
