package com.senacwebpatasdouradas.demo.entity;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.List;

@Entity
@DiscriminatorValue("CLIENTE")
public class ClienteEntity extends UsuarioEntity {

    public ClienteEntity() {
    }

    @Override
    public List<SimpleGrantedAuthority> getAuthorities() {

        return List.of(new SimpleGrantedAuthority("ROLE_CLIENTE"));
    }
}